#ifndef _input_h_
#define _input_h_

void Input_Vis(char* ip,int x,int y,int lim,int color);
void Input_Invis(char* ip,int x,int y,int lim,int color);                      

#endif
